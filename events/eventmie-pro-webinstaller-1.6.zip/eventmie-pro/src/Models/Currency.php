<?php

namespace Classiebit\Eventmie\Models;

use Illuminate\Database\Eloquent\Model;


class Currency extends Model
{
    protected $guarded = [];
    
}

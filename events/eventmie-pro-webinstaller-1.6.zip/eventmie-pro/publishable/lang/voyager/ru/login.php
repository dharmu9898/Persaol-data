<?php

return [
    'loggingin'    => 'Вход в систему',
    'signin_below' => 'Вход в панель управления',
    'welcome'      => 'Панель управления, которой не хватало в Laravel',
];

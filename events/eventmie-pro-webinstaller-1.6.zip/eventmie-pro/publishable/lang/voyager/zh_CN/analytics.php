<?php

return [
    'by_pageview'            => '以 PV',
    'by_sessions'            => '以 Session',
    'by_users'               => '以用户',
    'no_client_id'           => '若需查看统计数据，您需要先注册 Google Analytics 并将所提供的网站 Client ID 以键名：<code>google_analytics_client_id</code> 添加到您的 Voyager 设置项。在 Google Developer Console 上获取您的 key 信息：',
    'set_view'               => '选择一个视图',
    'this_vs_last_week'      => '本周 VS 上周',
    'this_vs_last_year'      => '今年 VS 去年',
    'top_browsers'           => '使用最多的浏览器',
    'top_countries'          => '访问量最高的国家',
    'various_visualizations' => '复合图表',
];

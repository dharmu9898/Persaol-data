<?php

return [
    'last_week' => '上周',
    'last_year' => '去年',
    'this_week' => '本周',
    'this_year' => '今年',
];

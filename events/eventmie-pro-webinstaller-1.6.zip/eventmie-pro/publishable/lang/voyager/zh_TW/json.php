<?php

return [
    'invalid'           => 'JSON 無效',
    'invalid_message'   => '看起來您引入的是一個無效的 JSON',
    'valid'             => 'JSON 有效',
    'validation_errors' => '驗證錯誤',
];

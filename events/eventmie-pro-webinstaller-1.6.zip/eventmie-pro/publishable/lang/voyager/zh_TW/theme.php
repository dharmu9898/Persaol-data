<?php

return [
    'footer_copyright'  => '用 <i class="voyager-heart"></i> 製成，by',
    'footer_copyright2' => '用很多很多的朗姆酒製成',
];

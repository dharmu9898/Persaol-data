<?php

return [
    'symlink_created_text'   => '我們剛剛為您建立了缺失的軟連接。',
    'symlink_created_title'  => '丟失的存儲軟連接已被重新建立',
    'symlink_failed_text'    => '我們未能為您的應用程序生成缺失的軟連接，似乎您的主機提供商不支持它。',
    'symlink_failed_title'   => '無法建立丟失的存儲軟連接',
    'symlink_missing_button' => '修復',
    'symlink_missing_text'   => '我們找不到一個存儲軟連接，這可能會導致從瀏覽器加載媒體文件的問題。',
    'symlink_missing_title'  => '缺失的存儲軟連接',
];

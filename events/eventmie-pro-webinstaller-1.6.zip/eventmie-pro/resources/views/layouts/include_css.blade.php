<!-- Packages CSS -->
<link rel="stylesheet" href="{{ eventmie_asset('css/vendor_v1.6.css') }}">

<!-- Bootstrap RTL CSS only if langauge is RTL -->
@if(is_rtl())
<link rel="stylesheet" href="{{ eventmie_asset('css/bootstrap-rtl.min.css') }}">
@endif



<!-- App CSS -->
<link rel="stylesheet" href="{{ eventmie_asset('css/app_v1.6.css') }}">
